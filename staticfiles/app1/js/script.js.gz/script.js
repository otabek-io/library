import './messages';
import './book_detail';
import './base';
import './add_category_ajax';
import './book_list';